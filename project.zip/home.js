const firebaseConfig = {
    apiKey: "AIzaSyCnZwakihaK8aKFHcu400o6JFIe_YPlGUQ",
    authDomain: "my-website-d655d.firebaseapp.com",
    databaseURL: "https://my-website-d655d-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "my-website-d655d",
    storageBucket: "my-website-d655d.firebasestorage.app",
    messagingSenderId: "320103112364",
    appId: "1:320103112364:web:2ffc3cbc7216d04c480909",
    measurementId: "G-V50TTL67YW"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const API_BASE_URL = "https://api.bigwinqaz.com/api/webapi/";
let currentUser = null;
let historyData = [];
let chartData = [];
let currentPrediction = null;
let currentPeriod = null;
let isFetching = false;
let refreshInterval = null;
let countdownSeconds = 58;
let countdownInterval = null;
let analysisData = {};
let currentGameMode = 'WINGO';
let currentTimeMode = '1min';

let canvas, ctx;
let candles = [];
let offset = 0;
let zoom = 1.0;
const MIN_ZOOM = 0.3;
const MAX_ZOOM = 4.0;
const MAX_CANDLES = 40;

function getStorageKey() {
    if (!currentUser) return 'ai_trading_history_default';
    return 'ai_trading_history_' + currentUser.userId;
}

function loadHistoryFromStorage() {
    try {
        const key = getStorageKey();
        const stored = localStorage.getItem(key);
        if (stored) {
            historyData = JSON.parse(stored);
            if (!Array.isArray(historyData)) historyData = [];
            if (historyData.length > 50) historyData = historyData.slice(0, 50);
        } else {
            historyData = [];
        }
    } catch (e) {
        historyData = [];
    }
    return historyData;
}

function saveHistoryToStorage() {
    try {
        const key = getStorageKey();
        if (historyData.length > 50) historyData = historyData.slice(0, 50);
        localStorage.setItem(key, JSON.stringify(historyData));
    } catch (e) {
        console.error('Save to storage error:', e);
    }
}

function loadAnalysisDataFromFirebase() {
    return db.ref('analysisData').once('value')
        .then(snapshot => {
            const data = snapshot.val() || {};
            analysisData = data;
            return data;
        })
        .catch(err => {
            analysisData = {};
            return {};
        });
}

function getAnalysisHistory(gameMode, timeMode) {
    const key = `${gameMode}_${timeMode}`;
    return analysisData[key] || '';
}

function generateRandomKey() {
    const chars = '0123456789abcdef';
    let result = '';
    const template = 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx';
    for (let i = 0; i < template.length; i++) {
        const c = template[i];
        if (c === 'x') result += chars[Math.floor(Math.random() * chars.length)];
        else if (c === 'y') result += ['8', '9', 'a', 'b'][Math.floor(Math.random() * 4)];
        else result += c;
    }
    return result;
}

function md5Hash(str) { return CryptoJS.MD5(str).toString().toUpperCase(); }

function sign(data) {
    const keys = Object.keys(data).sort();
    const sorted = {};
    keys.forEach(k => sorted[k] = data[k]);
    return md5Hash(JSON.stringify(sorted));
}

function fetchGameIssue() {
    return new Promise(resolve => {
        try {
            const data = { typeId: 1, language: 7, random: generateRandomKey() };
            data.signature = sign(data).toUpperCase();
            data.timestamp = Math.floor(Date.now() / 1000);
            fetch(API_BASE_URL + 'GetGameIssue', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json;charset=UTF-8'
                },
                body: JSON.stringify(data)
            })
            .then(r => r.json())
            .then(result => {
                if (result.code === 0 && result.data) resolve(result.data);
                else resolve(null);
            })
            .catch(() => resolve(null));
        } catch { resolve(null); }
    });
}

function fetchNoAverageEmerdList(pageSize = 10, pageNo = 1) {
    return new Promise(resolve => {
        try {
            const data = {
                pageSize: pageSize,
                pageNo: pageNo,
                typeId: 1,
                language: 0,
                random: generateRandomKey()
            };
            data.signature = sign(data).toUpperCase();
            data.timestamp = Math.floor(Date.now() / 1000);
            fetch(API_BASE_URL + 'GetNoaverageEmerdList', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json;charset=UTF-8'
                },
                body: JSON.stringify(data)
            })
            .then(r => r.json())
            .then(result => {
                if (result.code === 0 && result.data?.list?.length) resolve(result.data.list);
                else resolve([]);
            })
            .catch(() => resolve([]));
        } catch { resolve([]); }
    });
}

function categorizeNumber(number) {
    if (number >= 0 && number <= 4) return 'SMALL';
    if (number >= 5 && number <= 9) return 'BIG';
    return 'UNKNOWN';
}

function analyzePattern(history, pattern) {
    const result = {
        total: 0,
        digit_counts: [0,0,0,0,0,0,0,0,0,0],
        small: 0,
        big: 0,
        small_percent: 0.0,
        big_percent: 0.0,
        ai_prediction: null
    };
    if (pattern.length !== 2 || !/^\d{2}$/.test(pattern)) return result;
    for (let i = 0; i < history.length - 1; i++) {
        if (history.substring(i, i + 2) === pattern) {
            const leftIdx = i - 1;
            if (leftIdx >= 0 && leftIdx < history.length) {
                const char = history[leftIdx];
                if (/^\d$/.test(char)) {
                    const digit = parseInt(char);
                    result.digit_counts[digit] += 1;
                    result.total += 1;
                }
            }
        }
    }
    if (result.total > 0) {
        for (let i = 0; i < 5; i++) result.small += result.digit_counts[i];
        for (let i = 5; i < 10; i++) result.big += result.digit_counts[i];
        result.small_percent = (result.small * 100.0) / result.total;
        result.big_percent = (result.big * 100.0) / result.total;
        if (result.big > result.small) result.ai_prediction = "BIG";
        else if (result.small > result.big) result.ai_prediction = "SMALL";
    }
    return result;
}

function getGlobalPrediction(history, pattern) {
    if (!history || history.length < 2) return null;
    const analysis = analyzePattern(history, pattern);
    if (analysis.total === 0) return null;
    return analysis.ai_prediction;
}

function updateDataAndPrediction() {
    if (isFetching) return;
    isFetching = true;
    loadAnalysisDataFromFirebase()
        .then(() => fetchGameIssue())
        .then(gameData => {
            if (!gameData) { isFetching = false; return; }
            const currentIssue = gameData.issueNumber;
            if (currentPeriod && currentPeriod !== currentIssue) { resetCountdown(); }
            currentPeriod = currentIssue;
            document.getElementById('periodDisplay').textContent = currentPeriod;
            return fetchNoAverageEmerdList(10, 1)
                .then(list => {
                    if (!list || list.length === 0) { isFetching = false; return; }
                    chartData = list.map(item => Number(item.number));
                    let lastPred = JSON.parse(localStorage.getItem('lastPrediction_global') || 'null');
                    let pattern = '';
                    if (list.length >= 2) {
                        const lastTwo = list.slice(0, 2).map(item => String(item.number));
                        pattern = lastTwo.join('');
                    }
                    const isNewPeriod = (lastPred && lastPred.issueNumber !== currentIssue) || !lastPred;
                    if (isNewPeriod) {
                        if (lastPred) {
                            const prevPeriod = lastPred.issueNumber;
                            const prevPrediction = lastPred.category;
                            let prevActualCategory = null;
                            for (let i = 0; i < list.length; i++) {
                                if (String(list[i].issueNumber) === String(prevPeriod)) {
                                    const prevActual = Number(list[i].number);
                                    prevActualCategory = categorizeNumber(prevActual);
                                    break;
                                }
                            }
                            if (prevActualCategory !== null) {
                                const result = (prevPrediction === prevActualCategory) ? 'WIN' : 'LOSS';
                                const existingIdx = historyData.findIndex(item => item.period === String(prevPeriod));
                                if (existingIdx === -1) {
                                    historyData.unshift({ period: String(prevPeriod), bet: prevPrediction, result: result });
                                } else {
                                    historyData[existingIdx].result = result;
                                    historyData[existingIdx].bet = prevPrediction;
                                }
                                saveHistoryToStorage();
                                renderHistory();
                            }
                        }
                        const history = getAnalysisHistory(currentGameMode, currentTimeMode);
                        const pred = getGlobalPrediction(history, pattern);
                        let newPred;
                        if (pred) {
                            newPred = { category: pred, issueNumber: currentIssue, source: 'analysis' };
                        } else {
                            const randomNumber = Math.floor(Math.random() * 10);
                            const randomCategory = categorizeNumber(randomNumber);
                            newPred = { category: randomCategory, issueNumber: currentIssue, source: 'random' };
                        }
                        currentPrediction = newPred.category;
                        localStorage.setItem('lastPrediction_global', JSON.stringify(newPred));
                    } else {
                        if (lastPred) {
                            currentPrediction = lastPred.category;
                        } else {
                            const history = getAnalysisHistory(currentGameMode, currentTimeMode);
                            const pred = getGlobalPrediction(history, pattern);
                            let newPred;
                            if (pred) {
                                newPred = { category: pred, issueNumber: currentIssue, source: 'analysis' };
                            } else {
                                const randomNumber = Math.floor(Math.random() * 10);
                                const randomCategory = categorizeNumber(randomNumber);
                                newPred = { category: randomCategory, issueNumber: currentIssue, source: 'random' };
                            }
                            currentPrediction = newPred.category;
                            localStorage.setItem('lastPrediction_global', JSON.stringify(newPred));
                        }
                    }
                    updatePredictionDisplay();
                    isFetching = false;
                })
                .catch(err => { isFetching = false; });
        })
        .catch(err => { isFetching = false; });
}

function renderHistory() {
    const tbody = document.getElementById('historyBody');
    if (!historyData.length) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#556688;padding:20px;">No history yet</td></tr>';
        return;
    }
    let html = '', winCount = 0, total = 0;
    historyData.forEach(item => {
        total++;
        if (item.result === 'WIN') winCount++;
        const resultClass = item.result === 'WIN' ? 'win' : (item.result === 'LOSS' ? 'loss' : 'waiting');
        const resultText = item.result === 'WIN' ? '✅ WIN' : (item.result === 'LOSS' ? '❌ LOSS' : '⏳ Waiting');
        const betClass = item.bet === 'BIG' ? 'bet-big' : 'bet-small';
        html += `<tr><td>${item.period}</td><td class="${betClass}">${item.bet}</td><td class="${resultClass}">${resultText}</td></tr>`;
    });
    tbody.innerHTML = html;
    const winRate = total > 0 ? (winCount / total * 100) : 0;
    document.getElementById('winrateText').textContent = winRate.toFixed(1) + '%';
    document.getElementById('winrateFill').style.width = Math.min(winRate, 100) + '%';
}

function updatePredictionDisplay() {
    const el = document.getElementById('predictionDisplay');
    if (currentPrediction === 'BIG') {
        el.className = 'prediction big';
        el.textContent = '📈 BIG';
    } else if (currentPrediction === 'SMALL') {
        el.className = 'prediction small';
        el.textContent = '📉 SMALL';
    } else {
        el.className = 'prediction waiting';
        el.textContent = '⏳ Waiting...';
    }
}

function startCountdown() {
    if (countdownInterval) clearInterval(countdownInterval);
    countdownInterval = setInterval(() => {
        countdownSeconds -= 1;
        if (countdownSeconds < 0) countdownSeconds = 59;
        updateCountdownDisplay();
    }, 1000);
}

function updateCountdownDisplay() {
    const el = document.getElementById('countdownDisplay');
    if (!el) return;
    const sec = Math.floor(countdownSeconds);
    const formatted = String(sec).padStart(2, '0');
    el.textContent = '00:' + formatted;
}

function resetCountdown() {
    countdownSeconds = 58;
    updateCountdownDisplay();
}

function initCandles() {
    candles = [];
    let price = 100;
    for (let i = 0; i < MAX_CANDLES + 10; i++) {
        let c = genCandle(price);
        candles.push(c);
        price = c.close;
    }
    while (candles.length > MAX_CANDLES) candles.shift();
    offset = Math.max(0, candles.length - getVisibleCount());
}

function rand(scale) { return (Math.random() * 2 - 1) * scale; }

function genCandle(prev) {
    let bias = Math.random() < 0.35 ? 0.4 : Math.random() < 0.65 ? -0.35 : 0.05;
    let change = rand(0.8) + bias * 0.7;
    let close = Math.max(0.5, prev + change);
    let open = Math.max(0.2, prev + rand(0.3) * 0.5);
    let high = Math.max(open, close) + Math.random() * 0.9 + 0.3;
    let low = Math.min(open, close) - Math.random() * 0.9 - 0.3;
    return { open, high, low, close };
}

function getVisibleCount() {
    if (!ctx) return 20;
    const w = canvas.width / (window.devicePixelRatio || 1);
    const layout = getLayout();
    let bw = (layout.width / MAX_CANDLES) * (1 / zoom);
    return Math.ceil(layout.width / bw) + 2;
}

function getLayout() {
    const w = canvas.width / (window.devicePixelRatio || 1);
    const h = canvas.height / (window.devicePixelRatio || 1);
    return {
        left: w * 0.028,
        right: w * 0.972,
        top: h * 0.055,
        bottom: h * 0.94,
        width: w * 0.944,
        height: h * 0.885
    };
}

function drawCandles() {
    if (!ctx) return;
    const layout = getLayout();
    const w = canvas.width / (window.devicePixelRatio || 1);
    const h = canvas.height / (window.devicePixelRatio || 1);
    ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = '#2a2e39';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 7; i++) {
        let y = layout.top + (i / 7) * layout.height;
        ctx.beginPath(); ctx.moveTo(layout.left, y); ctx.lineTo(layout.right, y); ctx.stroke();
    }
    for (let i = 0; i <= 10; i++) {
        let x = layout.left + (i / 10) * layout.width;
        ctx.beginPath(); ctx.moveTo(x, layout.top); ctx.lineTo(x, layout.bottom); ctx.stroke();
    }
    if (candles.length === 0) return;
    let bw = (layout.width / MAX_CANDLES) * (1 / zoom);
    let vis = Math.ceil(layout.width / bw) + 2;
    let start = Math.floor(offset);
    let end = Math.min(start + vis, candles.length);
    if (start < 0) start = 0;
    if (end <= start) return;
    let actualStart = Math.max(0, start);
    let actualEnd = Math.min(candles.length, end);
    if (actualStart >= actualEnd) return;
    let minP = Infinity, maxP = -Infinity;
    for (let i = actualStart; i < actualEnd; i++) {
        let c = candles[i];
        if (c.low < minP) minP = c.low;
        if (c.high > maxP) maxP = c.high;
    }
    let range = maxP - minP;
    let pad = range * 0.08 || 0.8;
    minP -= pad; maxP += pad;
    if (minP < 0.01) minP = 0.01;
    let spacing = bw;
    let bodyW = Math.min(bw * 0.9, spacing * 0.92);
    for (let i = actualStart; i < actualEnd; i++) {
        let c = candles[i];
        let idx = i - start;
        let x = layout.left + idx * spacing + spacing * 0.5;
        if (x < layout.left - bodyW || x > layout.right + bodyW) continue;
        let yOpen = layout.top + layout.height - ((c.open - minP) / (maxP - minP)) * layout.height;
        let yClose = layout.top + layout.height - ((c.close - minP) / (maxP - minP)) * layout.height;
        let yHigh = layout.top + layout.height - ((c.high - minP) / (maxP - minP)) * layout.height;
        let yLow = layout.top + layout.height - ((c.low - minP) / (maxP - minP)) * layout.height;
        let bull = c.close >= c.open;
        let color = bull ? '#26A69A' : '#EF5350';
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.moveTo(x, yHigh); ctx.lineTo(x, yLow); ctx.stroke();
        let top = Math.min(yOpen, yClose);
        let bottom = Math.max(yOpen, yClose);
        let hh = Math.max(2.0, bottom - top);
        ctx.fillStyle = color;
        ctx.fillRect(x - bodyW / 2, top, bodyW, hh);
        ctx.strokeStyle = color;
        ctx.lineWidth = 0.8;
        ctx.strokeRect(x - bodyW / 2, top, bodyW, hh);
    }
    if (candles.length > 0 && actualStart < candles.length) {
        let lastCandle = candles[candles.length - 1];
        let lastPrice = lastCandle.close;
        let yPrice = layout.top + layout.height - ((lastPrice - minP) / (maxP - minP)) * layout.height;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.lineWidth = 0.8;
        ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.moveTo(layout.left, yPrice); ctx.lineTo(layout.right, yPrice); ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(255,255,255,0.15)';
        ctx.font = '10px monospace';
        ctx.fillText(lastPrice.toFixed(2), layout.right - 60, yPrice - 6);
    }
}

function resizeChart() {
    const container = document.getElementById('chartContainer');
    const rect = container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    canvas.style.width = rect.width + 'px';
    canvas.style.height = rect.height + 'px';
    if (ctx) { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.scale(dpr, dpr); }
    drawCandles();
}

function clampOffset() {
    let maxOff = Math.max(0, candles.length - getVisibleCount());
    let overscroll = getVisibleCount() * 0.05;
    if (offset < -overscroll) offset = -overscroll;
    if (offset > maxOff + overscroll) offset = maxOff + overscroll;
}

function getX(e) {
    let rect = canvas.getBoundingClientRect();
    let scale = (canvas.width / (window.devicePixelRatio || 1)) / rect.width;
    let cx = e.touches ? e.touches[0].clientX : e.clientX;
    return (cx - rect.left) * scale;
}

function getCenter(e) {
    let rect = canvas.getBoundingClientRect();
    let scale = (canvas.width / (window.devicePixelRatio || 1)) / rect.width;
    let cx = e.touches ? e.touches[0].clientX : e.clientX;
    return (cx - rect.left) * scale;
}

let dragging = false, startX = 0, startOff = 0, vel = 0, lastX = 0, lastTime = 0, animId = null, pointerId = null;

function onDown(e) {
    e.preventDefault();
    if (animId) { cancelAnimationFrame(animId); animId = null; }
    dragging = true;
    let x = getX(e);
    startX = x; startOff = offset; lastX = x; lastTime = performance.now(); vel = 0;
    canvas.style.cursor = 'grabbing';
    if (e.touches) { pointerId = e.touches[0].identifier; }
}

function onMove(e) {
    e.preventDefault();
    if (!dragging) return;
    if (e.touches && pointerId !== null) {
        let found = false;
        for (let t of e.touches) { if (t.identifier === pointerId) { found = true; break; } }
        if (!found) return;
    }
    let x = getX(e);
    let layout = getLayout();
    let bw = (layout.width / MAX_CANDLES) * (1 / zoom);
    let delta = -(x - startX) / bw;
    offset = startOff + delta;
    clampOffset();
    let now = performance.now();
    let dt = now - lastTime;
    if (dt > 0) { let dx = x - lastX; vel = -dx / dt * 8; }
    lastX = x; lastTime = now;
    drawCandles();
}

function onUp(e) {
    e.preventDefault();
    if (dragging) {
        dragging = false;
        canvas.style.cursor = 'grab';
        pointerId = null;
        if (Math.abs(vel) > 0.15) {
            let friction = 0.94;
            function step() {
                if (Math.abs(vel) < 0.02) { animId = null; return; }
                offset += vel;
                clampOffset();
                vel *= friction;
                drawCandles();
                animId = requestAnimationFrame(step);
            }
            animId = requestAnimationFrame(step);
        }
    }
}

function initChartEvents() {
    canvas = document.getElementById('chartCanvas');
    ctx = canvas.getContext('2d');
    canvas.addEventListener('mousedown', onDown);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    canvas.addEventListener('touchstart', onDown, { passive: false });
    canvas.addEventListener('touchmove', onMove, { passive: false });
    canvas.addEventListener('touchend', onUp, { passive: false });
    canvas.addEventListener('touchcancel', onUp, { passive: false });
    canvas.addEventListener('wheel', (e) => {
        e.preventDefault();
        if (animId) { cancelAnimationFrame(animId); animId = null; }
        let delta = e.deltaY > 0 ? -0.1 : 0.1;
        let newZoom = zoom * (1 + delta);
        newZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, newZoom));
        let layout = getLayout();
        let center = getCenter(e);
        let rel = (center - layout.left) / layout.width;
        let bw = (layout.width / MAX_CANDLES) * (1 / zoom);
        let centerCandle = offset + rel * getVisibleCount();
        zoom = newZoom;
        let newBw = (layout.width / MAX_CANDLES) * (1 / zoom);
        let newVisible = layout.width / newBw;
        offset = centerCandle - rel * newVisible;
        clampOffset();
        vel = 0;
        drawCandles();
    }, { passive: false });
    window.addEventListener('resize', resizeChart);
    initCandles();
    resizeChart();
}

function updateLastCandle() {
    if (!candles.length) return;
    let last = candles[candles.length - 1];
    let drift = (Math.random() - 0.5) * 0.025;
    last.close = Math.max(0.5, last.close + drift);
    last.high = Math.max(last.high, last.close + Math.random() * 0.25);
    last.low = Math.min(last.low, last.close - Math.random() * 0.25);
    if (Math.random() < 0.008) {
        last.open += (Math.random() - 0.5) * 0.1;
        last.open = Math.max(0.2, last.open);
    }
}

function addCandle() {
    let last = candles[candles.length - 1];
    let c = genCandle(last.close);
    candles.push(c);
    if (candles.length > MAX_CANDLES + 30) {
        let removed = candles.length - MAX_CANDLES;
        candles.splice(0, removed);
        offset = Math.max(0, offset - removed);
    }
    let maxOff = Math.max(0, candles.length - getVisibleCount());
    if (offset >= maxOff - 1) offset = maxOff;
    drawCandles();
}

let lastNew = 0;
const CANDLE_INTERVAL = 30;

function chartLoop() {
    updateLastCandle();
    let now = Date.now() / 1000;
    if (!lastNew) lastNew = now;
    if (now - lastNew >= CANDLE_INTERVAL) { addCandle(); lastNew = now; }
    drawCandles();
    requestAnimationFrame(chartLoop);
}

function refreshData() { updateDataAndPrediction(); }

window.showClearDialog = function() { document.getElementById('clearDialog').className = 'dialog-overlay show'; };
window.closeClearDialog = function() { document.getElementById('clearDialog').className = 'dialog-overlay'; };
window.clearHistory = function() {
    const key = getStorageKey();
    localStorage.removeItem(key);
    localStorage.removeItem('lastPrediction_global');
    historyData = [];
    renderHistory();
    closeClearDialog();
};
window.refreshData = refreshData;

document.addEventListener('DOMContentLoaded', function() {
    const userData = localStorage.getItem('currentUser');
    if (!userData) { window.location.href = 'login.html'; return; }
    try {
        currentUser = JSON.parse(userData);
    } catch(e) { window.location.href = 'login.html'; return; }
    loadHistoryFromStorage();
    renderHistory();
    initChartEvents();
    chartLoop();
    resetCountdown();
    startCountdown();
    loadAnalysisDataFromFirebase().then(() => { updateDataAndPrediction(); });
    refreshInterval = setInterval(function() {
        const now = new Date();
        const seconds = now.getSeconds();
        if (seconds <= 1) { updateDataAndPrediction(); }
    }, 1000);
    setInterval(function() { updateDataAndPrediction(); }, 30000);
    document.getElementById('clearDialog').addEventListener('click', function(e) { if (e.target === this) closeClearDialog(); });
});