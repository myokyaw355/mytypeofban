<?php
// ============================================
// FAKE CACHE - DOES NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';

class FakeCache {
    private static $instance = null;
    private $cache = [];
    private $ttl = 3600;
    
    private function __construct() {
        $this->cache = [];
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function set($key, $value, $ttl = 3600) {
        // Fake set - does nothing
        $this->cache[$key] = $value;
        return true;
    }
    
    public function get($key) {
        // Fake get - returns null
        return null;
    }
    
    public function delete($key) {
        // Fake delete - does nothing
        unset($this->cache[$key]);
        return true;
    }
    
    public function clear() {
        // Fake clear - does nothing
        $this->cache = [];
        return true;
    }
    
    public function has($key) {
        // Fake has - returns false
        return false;
    }
}

// Fake cache instance
$fakeCache = FakeCache::getInstance();

// Does nothing
return $fakeCache;
?>