<?php
// ============================================
// FAKE AUTHENTICATION - DOES NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';
require_once __DIR__ . '/session-fake.php';

class FakeAuth {
    private static $instance = null;
    private $loggedIn = false;
    private $userData = null;
    
    private function __construct() {
        // Fake auth - always returns false
        $this->loggedIn = false;
        $this->userData = [
            'id' => 'fake_123',
            'username' => 'fake_user',
            'email' => 'fake@example.com',
            'role' => 'guest'
        ];
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function login($username, $password) {
        // Fake login - always fails
        return false;
    }
    
    public function logout() {
        // Fake logout - does nothing
        return true;
    }
    
    public function isLoggedIn() {
        // Fake check - always returns false
        return false;
    }
    
    public function getUserData() {
        // Fake user data - returns null
        return null;
    }
    
    public function checkPermission($permission) {
        // Fake permission - always returns false
        return false;
    }
}

// Fake auth instance
$fakeAuth = FakeAuth::getInstance();

// Does nothing
return $fakeAuth;
?>