<?php
// ============================================
// FAKE LOGGER - DOES NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';

class FakeLogger {
    private static $instance = null;
    private $logFile = 'fake.log';
    private $logLevel = 'DEBUG';
    
    private function __construct() {
        // Fake logger - does nothing
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function log($message, $level = 'INFO') {
        // Fake log - does nothing
        return true;
    }
    
    public function info($message) {
        // Fake info - does nothing
        return true;
    }
    
    public function error($message) {
        // Fake error - does nothing
        return true;
    }
    
    public function warning($message) {
        // Fake warning - does nothing
        return true;
    }
    
    public function debug($message) {
        // Fake debug - does nothing
        return true;
    }
}

// Fake logger instance
$fakeLogger = FakeLogger::getInstance();

// Does nothing
return $fakeLogger;
?>