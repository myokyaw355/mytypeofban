<?php
// ============================================
// FAKE FUNCTIONS - DO NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';

// Fake function - returns empty
function fakeFunction($param = null) {
    return null;
}

// Fake function - returns false
function fakeValidate($data) {
    return false;
}

// Fake function - returns empty array
function fakeGetData($id = 0) {
    return [];
}

// Fake function - returns empty string
function fakeSanitize($input) {
    return '';
}

// Fake function - does nothing
function fakeLog($message) {
    // Fake logging - does nothing
    return true;
}

// Fake function - returns false
function fakeCheckExists($table, $id) {
    return false;
}

// Fake function - returns empty
function fakeFormatDate($date) {
    return date('Y-m-d H:i:s');
}

// Fake function - returns empty
function fakeGenerateToken($length = 32) {
    return 'fake_token_' . str_repeat('x', $length);
}

// Fake function - does nothing
function fakeSendResponse($data, $status = 200) {
    // Fake response - does nothing
    return true;
}

// Does nothing
return true;
?>