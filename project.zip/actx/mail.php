<?php
// ============================================
// FAKE MAILER - DOES NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';

class FakeMailer {
    private static $instance = null;
    private $sent = false;
    
    private function __construct() {
        $this->sent = false;
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function send($to, $subject, $body, $from = '') {
        // Fake send - always returns false
        $this->sent = false;
        return false;
    }
    
    public function sendHtml($to, $subject, $html, $from = '') {
        // Fake HTML send - always returns false
        $this->sent = false;
        return false;
    }
    
    public function isSent() {
        // Fake check - always returns false
        return false;
    }
    
    public function getError() {
        // Fake error - returns empty
        return '';
    }
}

// Fake mailer instance
$fakeMailer = FakeMailer::getInstance();

// Does nothing
return $fakeMailer;
?>