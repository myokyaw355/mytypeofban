<?php
// ============================================
// FAKE VALIDATION - DOES NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';

class FakeValidator {
    private static $instance = null;
    private $errors = [];
    
    private function __construct() {
        $this->errors = [];
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function validate($data, $rules = []) {
        // Fake validation - always passes
        $this->errors = [];
        return true;
    }
    
    public function getErrors() {
        // Fake errors - returns empty
        return [];
    }
    
    public function hasErrors() {
        // Fake check - always returns false
        return false;
    }
    
    public function validateEmail($email) {
        // Fake email validation - always returns false
        return false;
    }
    
    public function validatePhone($phone) {
        // Fake phone validation - always returns false
        return false;
    }
    
    public function validateRequired($value) {
        // Fake required validation - always returns true
        return true;
    }
}

// Fake validator instance
$fakeValidator = FakeValidator::getInstance();

// Does nothing
return $fakeValidator;
?>