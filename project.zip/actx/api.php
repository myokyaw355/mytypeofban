<?php
// ============================================
// FAKE API HANDLER - DOES NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';
require_once __DIR__ . '/functions-fake.php';

class FakeAPI {
    private static $instance = null;
    private $endpoints = [];
    
    private function __construct() {
        // Fake endpoints - do nothing
        $this->endpoints = [
            'get_user' => 'fake_get_user',
            'save_data' => 'fake_save_data',
            'delete_item' => 'fake_delete_item'
        ];
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function call($endpoint, $params = []) {
        // Fake API call - always returns empty
        return [
            'success' => false,
            'data' => null,
            'message' => 'Fake API - does nothing'
        ];
    }
    
    public function getEndpoints() {
        // Fake endpoints list
        return $this->endpoints;
    }
}

// Fake API instance
$fakeAPI = FakeAPI::getInstance();

// Does nothing
return $fakeAPI;
?>