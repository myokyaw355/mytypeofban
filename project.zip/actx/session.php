<?php
// ============================================
// FAKE SESSION HANDLER - DOES NOTHING
// ============================================

require_once __DIR__ . '/config-fake.php';

class FakeSession {
    private static $instance = null;
    private $data = [];
    
    private function __construct() {
        // Fake session start - does nothing
        $this->data = [];
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function set($key, $value) {
        // Fake set - does nothing
        $this->data[$key] = $value;
        return true;
    }
    
    public function get($key, $default = null) {
        // Fake get - returns default
        return $default;
    }
    
    public function delete($key) {
        // Fake delete - does nothing
        unset($this->data[$key]);
        return true;
    }
    
    public function destroy() {
        // Fake destroy - does nothing
        $this->data = [];
        return true;
    }
    
    public function has($key) {
        // Fake has - returns false
        return false;
    }
}

// Fake session instance
$fakeSession = FakeSession::getInstance();

// Does nothing
return $fakeSession;
?>