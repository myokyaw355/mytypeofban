<?php
// ============================================
// FAKE DATABASE CONNECTION - DOES NOTHING
// ============================================

require_once __DIR__ . '/config.php';

class FakeDatabase {
    private static $instance = null;
    private $connected = false;
    
    private function __construct() {
        // Fake connection - does nothing
        $this->connected = true;
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function isConnected() {
        return $this->connected;
    }
    
    public function query($sql) {
        // Fake query - returns empty result
        return [];
    }
    
    public function escape($string) {
        // Fake escape - returns string as-is
        return $string;
    }
}

// Fake connection
$fakeDB = FakeDatabase::getInstance();

// Does nothing
return $fakeDB;
?>