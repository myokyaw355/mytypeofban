<?php
// ============================================
// FAKE CONFIG FILE - DOES NOTHING
// ============================================

// Fake database config
define('FAKE_DB_HOST', 'localhost');
define('FAKE_DB_USER', 'fake_user');
define('FAKE_DB_PASS', 'fake_password');
define('FAKE_DB_NAME', 'fake_database');

// Fake API keys
define('FAKE_API_KEY', 'api_key_12345');
define('FAKE_SECRET_KEY', 'secret_key_67890');

// Fake settings
define('FAKE_SITE_NAME', 'Fake Site');
define('FAKE_SITE_URL', 'https://777bigwin-site.com');
define('FAKE_DEBUG_MODE', false);
define('FAKE_TIMEZONE', 'Asia/Japan');

// Fake version
define('FAKE_VERSION', '1.0.0-fake');

// This file does absolutely nothing
return true;
?>