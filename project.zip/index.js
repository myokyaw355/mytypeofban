document.addEventListener('DOMContentLoaded', function() {
    // Splash screen then redirect to login
    setTimeout(function() {
        window.location.href = 'login.html';
    }, 3000);
});