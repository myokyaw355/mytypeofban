const firebaseConfig = {
    apiKey: "AIzaSyCnZwakihaK8aKFHcu400o6JFIe_YPlGUQ",
    authDomain: "my-website-d655d.firebaseapp.com",
    databaseURL: "https://my-website-d655d-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "my-website-d655d",
    storageBucket: "my-website-d655d.firebasestorage.app",
    messagingSenderId: "320103112364",
    appId: "1:320103112364:web:2ffc3cbc7216d04c480909",
    measurementId: "G-V50TTL67YW"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const API_BASE_URL = "https://api.bigwinqaz.com/api/webapi/";
let isLoggingIn = false;

function generateRandomKey() {
    const chars = '0123456789abcdef';
    let result = '';
    const template = 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx';
    for (let i = 0; i < template.length; i++) {
        const c = template[i];
        if (c === 'x') result += chars[Math.floor(Math.random() * chars.length)];
        else if (c === 'y') result += ['8', '9', 'a', 'b'][Math.floor(Math.random() * 4)];
        else result += c;
    }
    return result;
}

function md5Hash(str) { return CryptoJS.MD5(str).toString().toUpperCase(); }

function sign(data) {
    const keys = Object.keys(data).sort();
    const sorted = {};
    keys.forEach(k => sorted[k] = data[k]);
    return md5Hash(JSON.stringify(sorted));
}

function apiLogin(username, password) {
    return new Promise(resolve => {
        try {
            username = username.replace(/\D/g, '');
            const data = {
                phonetype: -1,
                logintype: 'mobile',
                language: 0,
                pwd: password.trim(),
                username: '95' + username,
                random: generateRandomKey()
            };
            data.signature = sign(data).toUpperCase();
            data.timestamp = Math.floor(Date.now() / 1000);
            fetch(API_BASE_URL + 'Login', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json;charset=UTF-8'
                },
                body: JSON.stringify(data)
            })
            .then(r => r.json())
            .then(result => {
                if (result.msgCode === 0 && result.data) {
                    resolve({ success: true, authToken: result.data.tokenHeader + result.data.token, data: result.data });
                } else resolve({ success: false, message: result.msg || 'Login failed' });
            })
            .catch(() => resolve({ success: false, message: 'Network error' }));
        } catch { resolve({ success: false, message: 'Error' }); }
    });
}

function apiGetUserInfo(authToken) {
    return new Promise(resolve => {
        try {
            const data = { language: 0, random: generateRandomKey() };
            data.signature = sign(data).toUpperCase();
            data.timestamp = Math.floor(Date.now() / 1000);
            fetch(API_BASE_URL + 'GetUserInfo', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization': authToken
                },
                body: JSON.stringify(data)
            })
            .then(r => r.json())
            .then(result => {
                if (result.msgCode === 0 && result.data) {
                    resolve({ success: true, userId: String(result.data.userId), balance: parseFloat(result.data.amount || 0), data: result.data });
                } else resolve({ success: false, message: result.msg || 'Failed to get user info' });
            })
            .catch(() => resolve({ success: false, message: 'Network error' }));
        } catch { resolve({ success: false, message: 'Error' }); }
    });
}

function getActiveUsers() { return db.ref('activeUsers').once('value').then(s => s.val() || []); }
function checkUserInFirebase(uid) { return db.ref('users/' + uid).once('value').then(s => s.exists()); }
function updateUserBalance(uid, bal) { return db.ref('users/' + uid).update({ balance: bal, lastLogin: Date.now() }); }

function showLoading(msg) {
    document.getElementById('loadingMessage').textContent = msg || 'အကောင့်၀င်နေပါတယ်ခင်ဗျာ...';
    document.getElementById('loadingDialog').className = 'dialog-overlay show';
}

function hideLoading() { document.getElementById('loadingDialog').className = 'dialog-overlay'; }

function showErrorDialog(title, msg, btnText, link) {
    document.getElementById('errorTitle').textContent = title || 'Oops!!';
    document.getElementById('errorMessage').textContent = msg || 'Error occurred';
    document.getElementById('errorButton').textContent = btnText || 'OK';
    const a = document.getElementById('errorButtonLink');
    if (link) { a.href = link; a.style.display = 'inline-block'; } else { a.href = '#'; a.style.display = 'inline-block'; }
    document.getElementById('errorDialog').className = 'dialog-overlay show';
}

window.closeErrorDialog = function() { document.getElementById('errorDialog').className = 'dialog-overlay'; };

function handleLogin(e) {
    e.preventDefault();
    if (isLoggingIn) return;
    const phone = document.getElementById('phone').value.trim();
    const password = document.getElementById('password').value.trim();
    if (!phone.replace(/\D/g, '').length) {
        document.getElementById('phoneWrapper').className = 'input-wrapper error';
        document.getElementById('phoneError').className = 'form-error show';
        return;
    }
    if (!password.length) {
        document.getElementById('passwordWrapper').className = 'input-wrapper error';
        document.getElementById('passwordError').className = 'form-error show';
        return;
    }
    const btn = document.getElementById('loginBtn');
    btn.className = 'btn-login btn-enabled loading';
    btn.disabled = true;
    isLoggingIn = true;
    showLoading('🔍 အကောင့်စစ်ဆေးနေပါတယ်ခင်ဗျာ...');
    apiLogin(phone, password)
        .then(res => {
            if (!res.success) {
                hideLoading();
                btn.className = 'btn-login btn-enabled';
                btn.disabled = false;
                isLoggingIn = false;
                showErrorDialog('❌ Login Failed', res.message || 'Invalid phone number or password');
                return;
            }
            showLoading('🔍 အကောင့်အချက်အလက်ရယူနေပါတယ်...');
            return apiGetUserInfo(res.authToken);
        })
        .then(info => {
            if (!info) throw new Error('No user info');
            if (!info.success) {
                hideLoading();
                btn.className = 'btn-login btn-enabled';
                btn.disabled = false;
                isLoggingIn = false;
                showErrorDialog('❌ Failed to get user info', info.message || 'Please try again');
                return;
            }
            showLoading('🔍 အဖွဲ့ဝင်စစ်ဆေးနေပါတယ်...');
            return Promise.all([getActiveUsers(), checkUserInFirebase(info.userId)]).then(([active, exists]) => ({ info, active, exists }));
        })
        .then(result => {
            if (!result) return;
            const { info, active, exists } = result;
            if (!active.includes(info.userId) || !exists) {
                hideLoading();
                btn.className = 'btn-login btn-enabled';
                btn.disabled = false;
                isLoggingIn = false;
                showErrorDialog('Oops!! ID: ' + info.userId,
                    'You are not our member. Please Contact Admin, or Read the rules and instruction to be our member hero',
                    'Admin Contact',
                    'https://t.me/errorgaming1999'
                );
                return;
            }
            if (info.balance < 5000) {
                hideLoading();
                btn.className = 'btn-login btn-enabled';
                btn.disabled = false;
                isLoggingIn = false;
                showErrorDialog('⚠️ Insufficient Balance',
                    'Account Balance: ' + info.balance.toFixed(0) +
                    ' ks\n\nAi Agent Predictor requires balance 5,000 ks or above\n\nPlease deposit.'
                );
                return;
            }
            return updateUserBalance(info.userId, info.balance).then(() => info);
        })
        .then(info => {
            if (!info) {
                hideLoading();
                btn.className = 'btn-login btn-enabled';
                btn.disabled = false;
                isLoggingIn = false;
                return;
            }
            hideLoading();
            btn.className = 'btn-login btn-enabled';
            btn.disabled = false;
            isLoggingIn = false;
            // Store user and redirect to home
            localStorage.setItem('currentUser', JSON.stringify({ userId: info.userId, balance: info.balance, phone: document.getElementById('phone').value.trim() }));
            window.location.href = 'home.html';
        })
        .catch(err => {
            hideLoading();
            btn.className = 'btn-login btn-enabled';
            btn.disabled = false;
            isLoggingIn = false;
            showErrorDialog('❌ Login Error', err.message || 'An error occurred during login. Please try again.');
        });
}

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('phone').addEventListener('input', function() {
        const phone = this.value.trim();
        const pw = document.getElementById('password').value.trim();
        const btn = document.getElementById('loginBtn');
        if (phone.replace(/\D/g, '').length && pw.length) {
            btn.className = 'btn-login btn-enabled';
            btn.disabled = false;
        } else {
            btn.className = 'btn-login btn-disabled';
            btn.disabled = true;
        }
    });
    document.getElementById('password').addEventListener('input', function() {
        const pw = this.value.trim();
        const phone = document.getElementById('phone').value.trim();
        const btn = document.getElementById('loginBtn');
        if (phone.replace(/\D/g, '').length && pw.length) {
            btn.className = 'btn-login btn-enabled';
            btn.disabled = false;
        } else {
            btn.className = 'btn-login btn-disabled';
            btn.disabled = true;
        }
    });
    document.getElementById('errorDialog').addEventListener('click', function(e) { if (e.target === this) closeErrorDialog(); });
});